<?php
require("dbc.php");

$productname = isset($_GET['name-submit'])?$_GET['name-submit']:"";
$cquantity = isset($_GET['quantity-submit'])?$_GET['quantity-submit']:"";
$ctotal = isset($_GET['order-total-submit'])?$_GET['order-total-submit']:"";
$ccash = isset($_GET['cash-submit'])?$_GET['cash-submit']:"";
$cchange = isset($_GET['change-submit'])?$_GET['change-submit']:"";
$ccapital = isset($_GET['capital-submit'])?$_GET['capital-submit']:"";
$ccost = isset($_GET['cost-submit'])?$_GET['cost-submit']:"";

$query = sprintf("INSERT INTO orderhistory (productname, cquantity, ctotal, ccash, cchange, ccapital, ccost) VALUES ('$productname', '$cquantity', '$ctotal', '$ccash', '$cchange', '$ccapital', '$ccost')");
$result = mysql_query($query);
if (!$result) {
die('Invalid query: ' . mysql_error());
}
else
{
echo '<script type="text/javascript">
window.location.href = "admin-index.php";
</script>';
}
?>