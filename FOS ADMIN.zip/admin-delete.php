<?php
require('dbc.php');

$id=$_REQUEST['id'];
$query = "DELETE FROM purchasecounter WHERE id=$id"; 
$result = mysql_query($query) or die ( mysql_error());
header("Location: admin-inventory.php"); 
?>