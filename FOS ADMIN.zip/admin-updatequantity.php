<?php
require('dbc.php');

$cquantity = isset($_GET['cquantity'])?$_GET['cquantity']:"";
$userinput = isset($_GET["idf"])?$_GET["idf"]:"";

$query = sprintf("UPDATE purchasecounter SET cquantity= '$cquantity' WHERE id= '$userinput'");
$result = mysql_query($query);

if (!$result) {
die('Invalid query: ' . mysql_error());
}
else
{
echo '<script type="text/javascript">
window.location.href = "admin-index.php";
</script>';
}

?>