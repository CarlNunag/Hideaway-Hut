<?php
require('dbc.php');

$id=$_REQUEST['id'];
$query = "DELETE FROM placedorders WHERE orderID=$id"; 
$result = mysql_query($query) or die ( mysql_error());
header("Location: admin-online-orders.php"); 
?>