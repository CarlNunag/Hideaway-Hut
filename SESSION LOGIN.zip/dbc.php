<?php
$hostname_dbcon = "localhost";
$database_dbcon = "hideawaydb";
$username_dbcon = "root";
$dbcon = mysql_pconnect($hostname_dbcon, $username_dbcon) or trigger_error(mysql_error(),E_USER_ERROR);
// Opens a connection to MySQL
$connection=mysql_connect ("localhost", "root");
if (!$connection) {
die('Not connected : ' . mysql_error());
}
// Select MySQL database
$db_selected = mysql_select_db("hideawaydb", $connection); if (!$db_selected) {
die ('Can\'t use database : ' . mysql_error());
}?>