<?php
require("dbc.php");
session_start();

$userID = isset($_GET['userID'])?$_GET['userID']:"";

$_SESSION['userID'] = $userID;

$sql = "SELECT * FROM useraccount WHERE userID='$userID'";
$result = mysql_query($sql);

    if (mysql_num_rows($result) == 1) {
             
        $_SESSION['userID'] = $userID;
            
        $_SESSION['userName'] = $userName;
        echo'<script>alert("Login Success");</script>';
        header('location: ../FOS CUSTOMER/index.php');
    }
    else {
        echo '<script>alert("Login Error");</script>';
        echo '<script type="text/javascript">
        window.location.href = "index.html";
        </script>';
    }
?>