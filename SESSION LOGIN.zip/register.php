<?php
require("dbc.php");


$userID = isset($_GET['userID'])?$_GET['userID']:"";
$userName = isset($_GET['userName'])?$_GET['userName']:"";
$deliveryAddress = isset($_GET['deliveryAddress'])?$_GET['deliveryAddress']:"";
$contactNumber = isset($_GET['contactNumber'])?$_GET['contactNumber']:"";
$orderID = isset($_GET['orderID'])?$_GET['orderID']:"";

$query = sprintf("INSERT INTO useraccount (userID, userName, orderID, deliveryAddress, contactNumber) VALUES ('$userID', '$userName', '$orderID', '$deliveryAddress', '$contactNumber')");
$result = mysql_query($query);
if (!$result) {
die('Register error, please try another User ID. ' . mysql_error());

}
else
{
echo '<script type="text/javascript">
window.location.href = "index.html";
</script>';
}
?>